const users = require('./users-controller')
const articles = require('./aticles-controller')
const frofiles = require('./profiles-controller')
const tags = require('./tags-controler')

module.exports = {
  users,
  articles,
  frofiles,
  tags
}
