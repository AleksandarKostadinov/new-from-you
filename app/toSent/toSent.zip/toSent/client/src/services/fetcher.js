import fetch from 'isomorphic-fetch'
require('es6-promise').polyfill()

export default fetch
